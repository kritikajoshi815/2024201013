2024201013_q1.sh
Under q1, grep command was used in which two conditions were passed which searched for POST and 404

2024201013_q2.sh
In q2 awk command was used to sum up the required field using $4.
